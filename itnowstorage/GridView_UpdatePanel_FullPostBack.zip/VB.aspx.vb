﻿Imports System.Data

Partial Class VB
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Dim dt As New DataTable()
            dt.Columns.Add("FruitName")
            dt.Rows.Add("Apple")
            dt.Rows.Add("Mango")
            dt.Rows.Add("Banana")
            dt.Rows.Add("Orange")
            dt.Rows.Add("Pineapple")
            GridView1.DataSource = dt
            GridView1.DataBind()
        End If
        Me.RegisterPostBackControl()
    End Sub

    Private Sub RegisterPostBackControl()
        For Each row As GridViewRow In GridView1.Rows
            Dim lnkFull As LinkButton = TryCast(row.FindControl("lnkFull"), LinkButton)
            ScriptManager.GetCurrent(Me).RegisterPostBackControl(lnkFull)
        Next
    End Sub

    Protected Sub PartialPostBack(sender As Object, e As EventArgs)
        Dim fruitName As String = TryCast(TryCast(sender, LinkButton).NamingContainer, GridViewRow).Cells(0).Text
        Dim message As String = "alert('Partial PostBack: You clicked " & fruitName & "');"
        ScriptManager.RegisterClientScriptBlock(TryCast(sender, Control), Me.GetType(), "alert", message, True)
    End Sub

    Protected Sub FullPostBack(sender As Object, e As EventArgs)
        Dim fruitName As String = TryCast(TryCast(sender, LinkButton).NamingContainer, GridViewRow).Cells(0).Text
        Dim message As String = "alert('Full PostBack: You clicked " & fruitName & "');"
        ClientScript.RegisterClientScriptBlock(Me.GetType(), "alert", message, True)
    End Sub
End Class

