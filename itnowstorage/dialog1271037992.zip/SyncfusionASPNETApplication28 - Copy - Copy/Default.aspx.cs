﻿#region Copyright Syncfusion Inc. 2001-2017.
// Copyright Syncfusion Inc. 2001-2017. All rights reserved.
// Use of this code is subject to the terms of our license.
// A copy of the current license can be obtained at any time by e-mailing
// licensing@syncfusion.com. Any infringement will be prosecuted under
// applicable laws. 
#endregion
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SyncfusionASPNETApplication28
{
    [ScriptService]
    public partial class _Default : Page
    {
         
        protected void Page_Load(object sender, EventArgs e)
        {
            this.dialog.ShowOnInit = false;
        }
        protected void ejbtn_Click(object Sender, Syncfusion.JavaScript.Web.ButtonEventArgs e)
        {
                this.dialog.ShowOnInit = true;
        }
    }
}